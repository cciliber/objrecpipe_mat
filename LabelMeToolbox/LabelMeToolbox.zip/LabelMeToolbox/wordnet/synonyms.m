function D = synonyms(D);

